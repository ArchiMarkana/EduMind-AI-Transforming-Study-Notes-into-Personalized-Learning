// ==========================================
// LOAD DATA
// ==========================================

const uploadedFile = JSON.parse(
    localStorage.getItem("uploadedFile")
);

let quizData = null;

try {
    quizData = JSON.parse(
        localStorage.getItem("quiz")
    );
} catch (error) {
    console.error("Quiz data error:", error);
}

if (!uploadedFile || !uploadedFile.text_file) {
    alert("Please upload a document before generating a quiz.");
    window.location.href = "upload.html";
    throw new Error("No uploaded document is available.");
}



// ==========================================
// QUIZ DATA
// ==========================================

const quizBelongsToCurrentDocument =
    quizData &&
    quizData.text_file === uploadedFile.text_file;

let questions = quizBelongsToCurrentDocument &&
    Array.isArray(quizData.quiz)
    ? quizData.quiz
    : [];

let currentQuestion = 0;

let selectedAnswers = [];



// ==========================================
// ELEMENTS
// ==========================================

const fileName =
document.getElementById("fileName");

const questionCounter =
document.getElementById("questionCounter");

const progressFill =
document.getElementById("progressFill");

const question =
document.getElementById("question");

const optionsContainer =
document.getElementById("optionsContainer");

const resultCard =
document.getElementById("resultCard");

const scoreText =
document.getElementById("scoreText");



// ==========================================
// FILE INFO
// ==========================================

fileName.innerText =
uploadedFile.filename;



// ==========================================
// DISPLAY QUESTION
// ==========================================

function displayQuestion() {

    const current =
    questions[currentQuestion];

    question.innerText =
    current.question;

    questionCounter.innerText =
    `Question ${currentQuestion + 1} / ${questions.length}`;

    progressFill.style.width =
    `${((currentQuestion + 1) / questions.length) * 100}%`;

    optionsContainer.innerHTML = "";

    current.options.forEach((option, index) => {

        const optionDiv =
        document.createElement("div");

        optionDiv.className =
        "option";

        optionDiv.innerHTML = `

            <input
                type="radio"
                name="quizOption"
                id="option${index}"
                value="${option}"
                ${selectedAnswers[currentQuestion] === option ? "checked" : ""}
            >

            <label for="option${index}">
                ${option}
            </label>

        `;

        optionDiv.addEventListener("click", () => {

            document.getElementById(
                `option${index}`
            ).checked = true;

            selectedAnswers[currentQuestion] =
            option;

        });

        optionsContainer.appendChild(
            optionDiv
        );

    });

}

async function loadQuiz() {
    if (questions.length > 0) {
        selectedAnswers = new Array(questions.length).fill(null);
        displayQuestion();
        return;
    }

    question.innerText = "Generating quiz...";
    questionCounter.innerText = "Please wait";

    try {
        const response = await fetch(
            "http://127.0.0.1:5000/quiz",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    text_file: uploadedFile.text_file
                })
            }
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.error || "Failed to generate quiz.");
        }

        questions = Array.isArray(data.quiz) ? data.quiz : [];

        if (questions.length === 0) {
            throw new Error("No valid quiz questions were returned.");
        }

        localStorage.setItem("quiz", JSON.stringify(data));
        selectedAnswers = new Array(questions.length).fill(null);
        displayQuestion();
    } catch (error) {
        console.error("Quiz loading error:", error);
        alert(error.message);
        window.location.href = "summary.html";
    }
}

loadQuiz();



// ==========================================
// NEXT
// ==========================================

document.getElementById("nextBtn")
.addEventListener("click", () => {

    if (currentQuestion < questions.length - 1) {

        currentQuestion++;

        displayQuestion();

    }

});



// ==========================================
// PREVIOUS
// ==========================================

document.getElementById("prevBtn")
.addEventListener("click", () => {

    if (currentQuestion > 0) {

        currentQuestion--;

        displayQuestion();

    }

});



// ==========================================
// SUBMIT QUIZ
// ==========================================

document.getElementById("submitBtn")
.addEventListener("click", () => {

    let score = 0;

    questions.forEach((q, index) => {

        if (
            selectedAnswers[index] ===
            q.answer
        ) {

            score++;

        }

    });

    scoreText.innerText =
    `Score : ${score} / ${questions.length}`;

    const quizHistory = JSON.parse(
        localStorage.getItem("quizHistory")
    ) || [];

    quizHistory.push({
        filename: uploadedFile.filename,
        text_file: uploadedFile.text_file,
        score: score,
        totalQuestions: questions.length,
        percentage: questions.length
            ? Math.round((score / questions.length) * 100)
            : 0,
        date: new Date().toLocaleString(),
        completedAt: new Date().toISOString()
    });

    localStorage.setItem(
        "quizHistory",
        JSON.stringify(quizHistory)
    );

    resultCard.style.display =
    "block";

    resultCard.scrollIntoView({

        behavior: "smooth"

    });

});



// ==========================================
// RESTART QUIZ
// ==========================================

document.getElementById("restartBtn")
.addEventListener("click", () => {

    currentQuestion = 0;

    selectedAnswers = new Array(
        questions.length
    ).fill(null);

    resultCard.style.display =
    "none";

    displayQuestion();

});



// ==========================================
// BACK TO SUMMARY
// ==========================================

document.getElementById("summaryBtn")
.addEventListener("click", () => {

    window.location.href =
    "summary.html";

});



// ==========================================
// KEYBOARD SHORTCUTS
// ==========================================

document.addEventListener("keydown", (e) => {

    if (e.key === "ArrowRight") {

        if (currentQuestion < questions.length - 1) {

            currentQuestion++;

            displayQuestion();

        }

    }

    if (e.key === "ArrowLeft") {

        if (currentQuestion > 0) {

            currentQuestion--;

            displayQuestion();

        }

    }

});






// ==========================================
// END OF FILE
// ==========================================