document.addEventListener("DOMContentLoaded", function () {
    function getArray(key) {
        try {
            const value = JSON.parse(localStorage.getItem(key));
            return Array.isArray(value) ? value : [];
        } catch (error) {
            console.error("History storage error:", key, error);
            return [];
        }
    }

    function getObject(key) {
        try {
            return JSON.parse(localStorage.getItem(key));
        } catch (error) {
            return null;
        }
    }

    let documents = getArray("documents");
    let quizHistory = getArray("quizHistory");
    let flashcardHistory = getArray("flashcardHistory");
    const uploadedFile = getObject("uploadedFile");

    let user = null;
    try {
        user = JSON.parse(sessionStorage.getItem("loggedInUser"));
    } catch (error) {
        user = null;
    }

    const userName =
        user?.name ||
        user?.username ||
        user?.email ||
        "Student";

    document.getElementById("profileName").textContent = userName;
    document.getElementById("profileAvatar").textContent =
        userName.charAt(0).toUpperCase();

    const activities = [];

    documents.forEach(item => {
        activities.push({
            type: "upload",
            title: "Document Uploaded",
            document: item.name || item.filename || "Study Document",
            result: "Uploaded",
            date: item.date || item.uploadedOn || item.completedOn || null
        });
    });

    if (
        uploadedFile &&
        uploadedFile.text_file &&
        !documents.some(item =>
            (item.name || item.filename) === uploadedFile.filename
        )
    ) {
        activities.push({
            type: "upload",
            title: "Document Uploaded",
            document: uploadedFile.filename || uploadedFile.text_file,
            result: "Uploaded",
            date: null
        });
    }

    quizHistory.forEach(item => {
        const rawScore = Number(item.score ?? item.percentage ?? item.percentageScore);
        const total = Number(item.totalQuestions ?? item.total_questions ?? item.total);
        let displayScore = "Completed";

        if (Number.isFinite(rawScore)) {
            if (total > 0 && rawScore <= total) {
                displayScore = Math.round((rawScore / total) * 100) + "%";
            } else if (rawScore >= 0 && rawScore <= 100) {
                displayScore = Math.round(rawScore) + "%";
            }
        }

        activities.push({
            type: "quiz",
            title: "Quiz Completed",
            document: item.filename || item.document || item.text_file || "Study Document",
            result: displayScore,
            date: item.completedAt || item.completedOn || item.date || item.timestamp || null
        });
    });

    flashcardHistory.forEach(item => {
        activities.push({
            type: "flashcard",
            title: "Flashcards Studied",
            document: item.filename || item.document || "Study Document",
            result: (item.totalCards || item.cardsStudied || "Session") + " cards",
            date: item.studiedOn || item.completedAt || item.date || item.timestamp || null
        });
    });

    document.getElementById("totalActivities").textContent = activities.length;
    document.getElementById("totalUploads").textContent =
        activities.filter(item => item.type === "upload").length;
    document.getElementById("totalQuizzes").textContent = quizHistory.length;
    document.getElementById("totalStudySessions").textContent =
        flashcardHistory.length;

    const historyList = document.getElementById("historyList");
    const resultCount = document.getElementById("resultCount");
    const searchInput = document.getElementById("searchInput");
    const activityFilter = document.getElementById("activityFilter");

    function formatDate(value) {
        if (!value) return "Date unavailable";
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return String(value);
        return date.toLocaleString("en-IN", {
            day: "numeric",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        });
    }

    function renderHistory() {
        const searchValue = searchInput.value.toLowerCase().trim();
        const filterValue = activityFilter.value;

        const filtered = activities
            .filter(item =>
                item.document.toLowerCase().includes(searchValue) &&
                (filterValue === "all" || item.type === filterValue)
            )
            .sort((a, b) =>
                new Date(b.date || 0).getTime() -
                new Date(a.date || 0).getTime()
            );

        resultCount.textContent =
            filtered.length + (filtered.length === 1 ? " activity" : " activities");

        if (filtered.length === 0) {
            historyList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
                    <h3>No Activities Found</h3>
                    <p>Try another search or complete a learning activity.</p>
                </div>
            `;
            return;
        }

        historyList.innerHTML = "";
        filtered.forEach(item => {
            const row = document.createElement("div");
            row.className = "history-item";

            const icon = document.createElement("div");
            icon.className = "history-icon";

            if (item.type === "upload") {
                icon.innerHTML = '<i class="fa-solid fa-upload"></i>';
                icon.classList.add("purple");
            } else if (item.type === "quiz") {
                icon.innerHTML = '<i class="fa-solid fa-circle-question"></i>';
                icon.classList.add("orange");
            } else {
                icon.innerHTML = '<i class="fa-solid fa-layer-group"></i>';
                icon.classList.add("blue");
            }

            const details = document.createElement("div");
            details.className = "history-details";
            details.innerHTML =
                "<h3>" + item.title + "</h3>" +
                "<p>" + item.document + "</p>";

            const result = document.createElement("div");
            result.className = "history-result";
            result.innerHTML =
                "<strong>" + item.result + "</strong>" +
                "<small>" +
                (item.type === "quiz"
                    ? "Quiz result"
                    : item.type === "flashcard"
                        ? "Study activity"
                        : "Document status") +
                "</small>";

            const date = document.createElement("div");
            date.className = "history-date";
            date.textContent = formatDate(item.date);

            row.appendChild(icon);
            row.appendChild(details);
            row.appendChild(result);
            row.appendChild(date);
            historyList.appendChild(row);
        });
    }

    searchInput.addEventListener("input", renderHistory);
    activityFilter.addEventListener("change", renderHistory);
    renderHistory();

    document.getElementById("clearHistoryBtn")
        .addEventListener("click", function () {
            if (!confirm("Clear your learning history? This cannot be undone.")) {
                return;
            }

            localStorage.removeItem("documents");
            localStorage.removeItem("quizHistory");
            localStorage.removeItem("flashcardHistory");
            localStorage.removeItem("studyHistory");
            window.location.reload();
        });
});
