// ==========================================
// LOAD DATA
// ==========================================

const uploadedFile = JSON.parse(
    localStorage.getItem("uploadedFile")
);

let flashcardData = null;

try {
    flashcardData = JSON.parse(
        localStorage.getItem("flashcards")
    );
} catch (error) {
    console.error("Flashcard data error:", error);
}

if (!uploadedFile || !uploadedFile.text_file) {
    alert("Please upload a document before generating flashcards.");
    window.location.href = "upload.html";
    throw new Error("No uploaded document is available.");
}



// ==========================================
// ELEMENTS
// ==========================================

const flashcard = document.getElementById("flashcard");

const question = document.getElementById("question");

const answer = document.getElementById("answer");

const progressFill = document.getElementById("progressFill");

const progressText = document.getElementById("progressText");

const fileName = document.getElementById("fileName");

const cardCount = document.getElementById("cardCount");



// ==========================================
// FLASHCARD DATA
// ==========================================

let cards = flashcardData && Array.isArray(flashcardData.flashcards)
    ? flashcardData.flashcards.filter(card =>
        card &&
        typeof card.question === "string" &&
        typeof card.answer === "string" &&
        card.question.trim() &&
        card.answer.trim()
      )
    : [];

let currentIndex = 0;



// ==========================================
// FILE INFO
// ==========================================

fileName.innerText = uploadedFile.filename;

cardCount.innerText =
cards.length > 0
    ? cards.length + " Flashcards Generated"
    : "Loading flashcards...";



// ==========================================
// DISPLAY CARD
// ==========================================

function displayCard() {

    if (cards.length === 0) {
        question.innerText = "Loading flashcards...";
        answer.innerText = "";
        progressText.innerText = "0 / 0";
        progressFill.style.width = "0%";
        return;
    }

    flashcard.classList.remove("flipped");

    question.innerText =
        cards[currentIndex].question;

    answer.innerText =
        cards[currentIndex].answer;

    progressText.innerText =
        (currentIndex + 1) +
        " / " +
        cards.length;

    progressFill.style.width =
        ((currentIndex + 1) / cards.length) * 100 + "%";

}

displayCard();

async function loadFlashcards() {
    if (cards.length > 0) {
        return;
    }

    try {
        const response = await fetch(
            "http://127.0.0.1:5000/flashcards",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    text_file: uploadedFile.text_file
                })
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Failed to generate flashcards.");
        }

        cards = Array.isArray(data.flashcards)
            ? data.flashcards.filter(card =>
                card &&
                typeof card.question === "string" &&
                typeof card.answer === "string" &&
                card.question.trim() &&
                card.answer.trim()
              )
            : [];

        if (cards.length === 0) {
            throw new Error("No valid flashcards were returned.");
        }

        localStorage.setItem(
            "flashcards",
            JSON.stringify(data)
        );

        currentIndex = 0;
        cardCount.innerText = cards.length + " Flashcards Generated";
        displayCard();
    } catch (error) {
        console.error("Flashcard loading error:", error);
        question.innerText = "Unable to load flashcards";
        answer.innerText = error.message;
        cardCount.innerText = "Flashcards unavailable";
        progressText.innerText = "0 / 0";
    }
}

loadFlashcards();



// ==========================================
// FLIP CARD
// ==========================================

function flipCard() {

    flashcard.classList.toggle("flipped");

}

flashcard.addEventListener(
    "click",
    flipCard
);

document.getElementById("flipBtn")
.addEventListener(
    "click",
    flipCard
);



// ==========================================
// NEXT CARD
// ==========================================

document.getElementById("nextBtn")
.addEventListener("click", () => {

    if (currentIndex < cards.length - 1) {

        currentIndex++;

        displayCard();

    }

});



// ==========================================
// PREVIOUS CARD
// ==========================================

document.getElementById("prevBtn")
.addEventListener("click", () => {

    if (currentIndex > 0) {

        currentIndex--;

        displayCard();

    }

});
// ==========================================
// SHUFFLE FLASHCARDS
// ==========================================

document.getElementById("shuffleBtn")
.addEventListener("click", () => {

    for (let i = cards.length - 1; i > 0; i--) {

        const j = Math.floor(Math.random() * (i + 1));

        [cards[i], cards[j]] = [cards[j], cards[i]];

    }

    currentIndex = 0;

    displayCard();

});



// ==========================================
// RESTART FLASHCARDS
// ==========================================

document.getElementById("restartBtn")
.addEventListener("click", () => {

    currentIndex = 0;

    displayCard();

});



// ==========================================
// DOWNLOAD FLASHCARDS
// ==========================================

document.getElementById("downloadBtn")
.addEventListener("click", () => {

    let content =

`EduMind AI Flashcards

============================

File : ${uploadedFile.filename}

Total Flashcards : ${cards.length}

============================

`;

    cards.forEach((card, index) => {

        content +=

`Flashcard ${index + 1}

Question:
${card.question}

Answer:
${card.answer}

----------------------------------------

`;

    });

    const blob = new Blob(

        [content],

        {

            type: "text/plain"

        }

    );

    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");

    a.href = url;

    a.download = "Flashcards.txt";

    document.body.appendChild(a);

    a.click();

    document.body.removeChild(a);

    URL.revokeObjectURL(url);

});



// ==========================================
// BACK TO SUMMARY
// ==========================================

document.getElementById("summaryBtn")
.addEventListener("click", () => {

    window.location.href = "summary.html";

});



// ==========================================
// KEYBOARD SHORTCUTS
// ==========================================

document.addEventListener("keydown", (e) => {

    switch (e.key) {

        case "ArrowRight":

            if (currentIndex < cards.length - 1) {

                currentIndex++;

                displayCard();

            }

            break;

        case "ArrowLeft":

            if (currentIndex > 0) {

                currentIndex--;

                displayCard();

            }

            break;

        case " ":

            e.preventDefault();

            flipCard();

            break;

    }

});



// ==========================================
// SAVE STUDY HISTORY
// ==========================================

let flashcardHistory = JSON.parse(

    localStorage.getItem("flashcardHistory")

) || [];

flashcardHistory.push({

    filename: uploadedFile.filename,

    totalCards: cards.length,

    studiedOn: new Date().toLocaleString()

});

localStorage.setItem(

    "flashcardHistory",

    JSON.stringify(flashcardHistory)

);



// ==========================================
// OPTIONAL AUTO FLIP
// ==========================================

// Uncomment if you want the card to
// automatically flip after 5 seconds.

/*

setInterval(() => {

    flashcard.classList.toggle("flipped");

}, 5000);

*/



// ==========================================
// END OF FILE
// ==========================================