
const API_URL = "http://127.0.0.1:5000";

const chatArea = document.getElementById("chatArea");
const messageInput = document.getElementById("messageInput");
const sendBtn = document.getElementById("sendBtn");
const documentName = document.getElementById("documentName");
const welcomeMessage = document.getElementById("welcomeMessage");


// =====================================================
// LOAD UPLOADED DOCUMENT
// =====================================================

let uploadedFile = null;

try {
    uploadedFile = JSON.parse(
        localStorage.getItem("uploadedFile")
    );
} catch (error) {
    console.error("Uploaded file data error:", error);
}

if (!uploadedFile || !uploadedFile.text_file) {

    documentName.textContent = "No document selected";

    chatArea.innerHTML = `
        <div class="welcome-message">
            <div class="welcome-icon">!</div>
            <h2>No document found</h2>
            <p>Please upload a document before using AI Chat.</p>
            <a href="upload.html">Upload Document</a>
        </div>
    `;

    sendBtn.disabled = true;

} else {

    documentName.textContent =
        uploadedFile.filename || uploadedFile.text_file;

}


// =====================================================
// DISPLAY MESSAGE
// =====================================================

function addMessage(message, sender) {

    const messageDiv = document.createElement("div");

    messageDiv.className = `message ${sender}`;

    const avatar = document.createElement("div");

    avatar.className = "message-avatar";

    avatar.textContent = sender === "user" ? "U" : "AI";

    const contentWrapper = document.createElement("div");

    const label = document.createElement("div");

    label.className = "message-label";

    label.textContent = sender === "user"
        ? "You"
        : "EduMind AI";

    const content = document.createElement("div");

    content.className = "message-content";

    // textContent prevents HTML injection from chat responses
    content.textContent = message;

    contentWrapper.appendChild(label);
    contentWrapper.appendChild(content);

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentWrapper);

    chatArea.appendChild(messageDiv);

    chatArea.scrollTop = chatArea.scrollHeight;

    return messageDiv;
}


// =====================================================
// TYPING INDICATOR
// =====================================================

function showTyping() {

    const typingDiv = document.createElement("div");

    typingDiv.className = "message ai";
    typingDiv.id = "typingIndicator";

    typingDiv.innerHTML = `
        <div class="message-avatar">AI</div>

        <div>
            <div class="message-label">EduMind AI</div>

            <div class="message-content">
                <div class="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    `;

    chatArea.appendChild(typingDiv);

    chatArea.scrollTop = chatArea.scrollHeight;
}


// =====================================================
// SEND MESSAGE TO GEMINI
// =====================================================

async function sendMessage(customQuestion = null) {

    if (!uploadedFile || !uploadedFile.text_file) {
        alert("Please upload a document first.");
        return;
    }

    const question = (
        customQuestion || messageInput.value
    ).trim();

    if (!question) {
        return;
    }

    if (sendBtn.disabled) {
        return;
    }

    // Hide welcome screen
    if (welcomeMessage && welcomeMessage.isConnected) {
        welcomeMessage.remove();
    }

    // Display user message
    addMessage(question, "user");

    messageInput.value = "";
    messageInput.style.height = "auto";

    sendBtn.disabled = true;

    showTyping();

    try {

        const response = await fetch(`${API_URL}/chat`, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({

                text_file: uploadedFile.text_file,

                question: question

            })

        });

        const data = await response.json();

        const typing = document.getElementById("typingIndicator");

        if (typing) {
            typing.remove();
        }

        if (!response.ok || !data.success) {

            throw new Error(
                data.error || "Unable to generate AI response."
            );

        }

        addMessage(data.answer, "ai");

    } catch (error) {

        console.error("Chat Error:", error);

        const typing = document.getElementById("typingIndicator");

        if (typing) {
            typing.remove();
        }

        addMessage(
            "Sorry, I couldn't process your question. " +
            error.message,
            "ai"
        );

    } finally {

        sendBtn.disabled = false;

        messageInput.focus();

    }

}


// =====================================================
// SEND BUTTON
// =====================================================

sendBtn.addEventListener("click", function () {

    sendMessage();

});


// =====================================================
// ENTER TO SEND
// SHIFT + ENTER FOR NEW LINE
// =====================================================

messageInput.addEventListener("keydown", function (event) {

    if (event.key === "Enter" && !event.shiftKey) {

        event.preventDefault();

        sendMessage();

    }

});


// =====================================================
// AUTO RESIZE TEXTAREA
// =====================================================

messageInput.addEventListener("input", function () {

    this.style.height = "auto";

    this.style.height =
        Math.min(this.scrollHeight, 120) + "px";

});


// =====================================================
// SUGGESTED QUESTIONS
// =====================================================

document.querySelectorAll(".suggestion-card").forEach(card => {

    card.addEventListener("click", function () {

        const question = this.dataset.question;

        sendMessage(question);

    });

});


// =====================================================
// LOGOUT
// =====================================================

document.getElementById("logoutBtn").addEventListener(
    "click",
    function () {

        sessionStorage.removeItem("loggedInUser");

        window.location.href = "login.html";

    }
);
