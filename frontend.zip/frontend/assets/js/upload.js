// ===============================
// ELEMENTS
// ===============================

const dropArea = document.getElementById("dropArea");
const fileInput = document.getElementById("fileInput");
const browseBtn = document.getElementById("browseBtn");
const uploadBtn = document.getElementById("uploadBtn");

const fileName = document.getElementById("fileName");
const fileSize = document.getElementById("fileSize");

let selectedFile = null;

// ===============================
// OPEN FILE PICKER
// ===============================

browseBtn.addEventListener("click", () => {

    fileInput.click();

});

// ===============================
// FILE SELECT
// ===============================

fileInput.addEventListener("change", function () {

    if (this.files.length > 0) {

        handleFile(this.files[0]);

    }

});

// ===============================
// DRAG EVENTS
// ===============================

dropArea.addEventListener("dragover", (e) => {

    e.preventDefault();

    dropArea.classList.add("dragover");

});

dropArea.addEventListener("dragleave", () => {

    dropArea.classList.remove("dragover");

});

dropArea.addEventListener("drop", (e) => {

    e.preventDefault();

    dropArea.classList.remove("dragover");

    if (e.dataTransfer.files.length > 0) {

        handleFile(e.dataTransfer.files[0]);

    }

});

// ===============================
// FILE VALIDATION
// ===============================

function handleFile(file) {

    const allowedExtensions = [

        "pdf",
        "doc",
        "docx",
        "ppt",
        "pptx"

    ];

    const extension = file.name.split(".").pop().toLowerCase();

    if (!allowedExtensions.includes(extension)) {

        alert("Only PDF, DOC, DOCX, PPT and PPTX files are allowed.");

        return;

    }

    const maxSize = 50 * 1024 * 1024;

    if (file.size > maxSize) {

        alert("Maximum allowed size is 50 MB.");

        return;

    }

    selectedFile = file;

    fileName.innerText = file.name;

    fileSize.innerText = formatSize(file.size);

}

// ===============================
// FORMAT SIZE
// ===============================

function formatSize(bytes) {

    if (bytes < 1024)

        return bytes + " Bytes";

    if (bytes < 1024 * 1024)

        return (bytes / 1024).toFixed(2) + " KB";

    if (bytes < 1024 * 1024 * 1024)

        return (bytes / (1024 * 1024)).toFixed(2) + " MB";

    return (bytes / (1024 * 1024 * 1024)).toFixed(2) + " GB";

}

// ===============================
// UPLOAD BUTTON
// ===============================

uploadBtn.addEventListener("click", uploadFile);

// ===============================
// UPLOAD
// ===============================

async function uploadFile() {

    if (!selectedFile) {

        alert("Please select a file first.");

        return;

    }

    uploadBtn.disabled = true;

    uploadBtn.innerText = "Uploading...";

    const formData = new FormData();

    formData.append("file", selectedFile);

    try {

        const response = await fetch("http://127.0.0.1:5000/upload", {

            method: "POST",

            body: formData

        });

        const data = await response.json();

        if (response.ok) {

            localStorage.removeItem("summary");
            localStorage.removeItem("flashcards");
            localStorage.removeItem("quiz");

            let documents = [];
            try {
                documents = JSON.parse(
                    localStorage.getItem("documents")
                ) || [];
            } catch (error) {
                documents = [];
            }

            documents = documents.filter(item =>
                (item.name || item.filename) !== data.filename
            );

            documents.unshift({
                name: data.filename,
                filename: data.filename,
                text_file: data.text_file,
                size: data.size,
                date: new Date().toLocaleString()
            });

            localStorage.setItem(
                "documents",
                JSON.stringify(documents)
            );

            localStorage.setItem(

                "uploadedFile",

                JSON.stringify(data)

            );

            uploadBtn.innerText = "Upload Successful ✓";

            setTimeout(() => {

                window.location.href = "processing.html";

            }, 1500);

        }

        else {

            alert(data.error || "Upload failed.");

            uploadBtn.disabled = false;

            uploadBtn.innerText = "Upload & Analyze";

        }

    }

    catch (error) {

        console.error(error);

        alert("Cannot connect to backend.");

        uploadBtn.disabled = false;

        uploadBtn.innerText = "Upload & Analyze";

    }

}