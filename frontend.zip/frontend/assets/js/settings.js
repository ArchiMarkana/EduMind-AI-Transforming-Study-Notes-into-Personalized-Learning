document.addEventListener("DOMContentLoaded", function () {
    let loggedInUser = null;

    try {
        loggedInUser = JSON.parse(
            sessionStorage.getItem("loggedInUser")
        );
    } catch (error) {
        loggedInUser = null;
    }

    if (!loggedInUser) {
        window.location.href = "login.html";
        return;
    }

    const fullName = document.getElementById("fullName");
    const email = document.getElementById("email");
    const topUserName = document.getElementById("topUserName");
    const topAvatar = document.getElementById("topAvatar");
    const darkModeToggle = document.getElementById("darkModeToggle");
    const reminderToggle = document.getElementById("reminderToggle");
    const updatesToggle = document.getElementById("updatesToggle");
    const studyGoal = document.getElementById("studyGoal");
    const difficulty = document.getElementById("difficulty");
    const toast = document.getElementById("toast");

    let users = [];
    try {
        users = JSON.parse(localStorage.getItem("users")) || [];
        if (!Array.isArray(users)) users = [];
    } catch (error) {
        users = [];
    }

    const userEmail = (loggedInUser.email || "").trim().toLowerCase();
    const currentUser = users.find(user =>
        (user.email || "").trim().toLowerCase() === userEmail
    );

    fullName.value = currentUser?.name || loggedInUser.name || "";
    email.value = currentUser?.email || loggedInUser.email || "";

    function updateHeader() {
        const name = fullName.value.trim() || "User";
        topUserName.textContent = name;
        topAvatar.textContent = name.charAt(0).toUpperCase();
    }

    updateHeader();

    function showToast(message) {
        if (!toast) return;
        toast.textContent = message;
        toast.classList.add("show");
        window.setTimeout(() => {
            toast.classList.remove("show");
        }, 2500);
    }

    document.getElementById("profileForm").addEventListener("submit", function (event) {
        event.preventDefault();

        const newName = fullName.value.trim();
        const newEmail = email.value.trim().toLowerCase();

        if (!newName || !newEmail) {
            showToast("Please fill in all fields.");
            return;
        }

        const duplicate = users.some(user =>
            (user.email || "").trim().toLowerCase() === newEmail &&
            (user.email || "").trim().toLowerCase() !== userEmail
        );

        if (duplicate) {
            showToast("This email is already registered.");
            return;
        }

        const userIndex = users.findIndex(user =>
            (user.email || "").trim().toLowerCase() === userEmail
        );

        if (userIndex !== -1) {
            users[userIndex].name = newName;
            users[userIndex].email = newEmail;
            localStorage.setItem("users", JSON.stringify(users));
        }

        loggedInUser = {
            ...loggedInUser,
            name: newName,
            email: newEmail
        };

        sessionStorage.setItem(
            "loggedInUser",
            JSON.stringify(loggedInUser)
        );

        showToast("Profile updated successfully.");
        updateHeader();
    });

    const savedDarkMode = localStorage.getItem("darkMode") === "true";
    darkModeToggle.checked = savedDarkMode;
    document.body.classList.toggle("dark-mode", savedDarkMode);

    darkModeToggle.addEventListener("change", function () {
        document.body.classList.toggle("dark-mode", this.checked);
        localStorage.setItem("darkMode", String(this.checked));
        showToast(this.checked ? "Dark mode enabled." : "Light mode enabled.");
    });

    reminderToggle.checked =
        localStorage.getItem("studyReminders") !== "false";
    updatesToggle.checked =
        localStorage.getItem("learningUpdates") !== "false";

    reminderToggle.addEventListener("change", function () {
        localStorage.setItem("studyReminders", String(this.checked));
        showToast("Reminder preference updated.");
    });

    updatesToggle.addEventListener("change", function () {
        localStorage.setItem("learningUpdates", String(this.checked));
        showToast("Notification preference updated.");
    });

    studyGoal.value = localStorage.getItem("studyGoal") || "30";
    difficulty.value = localStorage.getItem("quizDifficulty") || "Medium";

    document.getElementById("savePreferences")
        .addEventListener("click", function () {
            localStorage.setItem("studyGoal", studyGoal.value);
            localStorage.setItem("quizDifficulty", difficulty.value);
            showToast("Study preferences saved.");
        });

    document.getElementById("clearHistoryBtn")
        .addEventListener("click", function () {
            if (!confirm("Clear your quiz and study history?")) return;

            [
                "documents",
                "quizHistory",
                "flashcardHistory",
                "studyHistory"
            ].forEach(key => localStorage.removeItem(key));

            showToast("Learning history cleared.");
        });

    document.getElementById("logoutBtn")
        .addEventListener("click", function () {
            sessionStorage.removeItem("loggedInUser");
            window.location.href = "login.html";
        });
});
