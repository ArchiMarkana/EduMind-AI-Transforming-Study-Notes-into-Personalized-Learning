
document.addEventListener("DOMContentLoaded", function () {

    // =========================================
    // GET SAVED DATA
    // =========================================

    function getArray(key) {

        try {

            const data = JSON.parse(localStorage.getItem(key));

            return Array.isArray(data) ? data : [];

        } catch (error) {

            console.error("Storage error:", key, error);

            return [];

        }

    }

    const quizHistory = getArray("quizHistory");
    const studyHistory = getArray("studyHistory");
    const flashcardHistory = getArray("flashcardHistory");
    const combinedFlashcardHistory =
        flashcardHistory.length > 0
            ? flashcardHistory
            : studyHistory;

    let uploadedFile = null;

    try {

        uploadedFile = JSON.parse(
            localStorage.getItem("uploadedFile")
        );

    } catch (error) {

        console.error("Uploaded file error:", error);

    }


    // =========================================
    // USER INFORMATION
    // =========================================

    let user = null;

    try {

        user = JSON.parse(
            sessionStorage.getItem("loggedInUser")
        );

    } catch (error) {

        console.error("User data error:", error);

    }

    const userName =
        user?.name ||
        user?.username ||
        user?.email ||
        "Student";

    document.getElementById("profileName").textContent = userName;

    document.getElementById("profileAvatar").textContent =
        userName.charAt(0).toUpperCase();


    // =========================================
    // DOCUMENT COUNT
    // =========================================

    // Your current project stores the latest uploaded file.
    // Therefore this counts the current document, not all past uploads.

    const documentCount =
        uploadedFile && uploadedFile.text_file ? 1 : 0;


    // =========================================
    // FLASHCARD COUNT
    // =========================================

    // Supports common study-history count fields.
    // If your history stores one entry per card, it counts entries.

    let flashcardCount = 0;

    combinedFlashcardHistory.forEach(item => {

        const count =
            Number(item.cardsStudied) ||
            Number(item.cards_studied) ||
            Number(item.totalCards) ||
            Number(item.total_cards) ||
            1;

        flashcardCount += count;

    });


    // =========================================
    // QUIZ STATISTICS
    // =========================================

    function getScore(item) {

        const score = Number(
            item.score ??
            item.percentage ??
            item.percentageScore
        );

        if (!Number.isFinite(score)) {
            return null;
        }

        // Convert a score out of a total into a percentage.
        const total = Number(
            item.totalQuestions ??
            item.total_questions ??
            item.total
        );

        if (
            total > 0 &&
            score >= 0 &&
            score <= total
        ) {

            return (score / total) * 100;

        }

        return score;

    }

    const validScores = quizHistory
        .map(getScore)
        .filter(score =>
            score !== null &&
            score >= 0 &&
            score <= 100
        );

    const totalQuizzes = quizHistory.length;

    const averageScore = validScores.length
        ? validScores.reduce((sum, score) => sum + score, 0)
            / validScores.length
        : 0;


    // =========================================
    // UPDATE STAT CARDS
    // =========================================

    document.getElementById("totalDocuments").textContent =
        documentCount;

    document.getElementById("totalFlashcards").textContent =
        flashcardCount;

    document.getElementById("totalQuizzes").textContent =
        totalQuizzes;

    document.getElementById("averageScore").textContent =
        Math.round(averageScore) + "%";


    // =========================================
    // ACTIVITY SUMMARY
    // =========================================

    document.getElementById("activityDocuments").textContent =
        documentCount;

    document.getElementById("activityFlashcards").textContent =
        flashcardCount;

    document.getElementById("activityQuizzes").textContent =
        totalQuizzes;


    // =========================================
    // QUIZ PERFORMANCE CHART
    // =========================================

    const chartCanvas =
        document.getElementById("performanceChart");

    const emptyMessage =
        document.getElementById("performanceEmpty");

    if (validScores.length > 0) {

        emptyMessage.style.display = "none";

        const chartData = quizHistory
            .map((item, index) => ({
                score: getScore(item),
                label: item.date || item.completedAt ||
                    item.timestamp || `Quiz ${index + 1}`
            }))
            .filter(item =>
                item.score !== null &&
                item.score >= 0 &&
                item.score <= 100
            )
            .slice(-10);

        const labels = chartData.map((item, index) => {

            const date = new Date(item.label);

            return Number.isNaN(date.getTime())
                ? `Quiz ${index + 1}`
                : date.toLocaleDateString("en-IN", {
                    day: "numeric",
                    month: "short"
                });

        });

        if (typeof Chart === "undefined") {
            chartCanvas.style.display = "none";
            emptyMessage.textContent =
                "Quiz scores are available, but chart rendering is unavailable.";
            emptyMessage.style.display = "flex";
        } else {
            new Chart(chartCanvas, {

            type: "line",

            data: {

                labels: labels,

                datasets: [{

                    label: "Quiz Score",

                    data: chartData.map(item => item.score),

                    borderColor: "#7968e9",

                    backgroundColor: "rgba(121, 104, 233, 0.10)",

                    borderWidth: 3,

                    fill: true,

                    tension: 0.4,

                    pointRadius: 5,

                    pointBackgroundColor: "#7968e9"

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                scales: {

                    y: {

                        min: 0,

                        max: 100,

                        ticks: {
                            callback: value => value + "%"
                        }

                    }

                },

                plugins: {

                    legend: {
                        display: false
                    }

                }

            }

            });
        }

    } else {

        chartCanvas.style.opacity = "0.15";
        emptyMessage.style.display = "flex";

    }


    // =========================================
    // RECENT ACTIVITY TABLE
    // =========================================

    const activityTable =
        document.getElementById("activityTable");

    const activities = [];


    // Quiz activities

    quizHistory.forEach(item => {

        activities.push({

            type: "Quiz Completed",

            document:
                item.filename ||
                item.document ||
                item.text_file ||
                "Study Document",

            result: getScore(item),

            date:
                item.date ||
                item.completedAt ||
                item.timestamp ||
                null

        });

    });


    // Flashcard activities

    combinedFlashcardHistory.forEach(item => {

        activities.push({

            type: "Flashcards Studied",

            document:
                item.filename ||
                item.document ||
                "Study Document",

            result: null,

            date:
                item.date ||
                item.completedAt ||
                item.timestamp ||
                null

        });

    });


    // Sort newest first where dates are available

    activities.sort((a, b) => {

        const dateA = new Date(a.date || 0).getTime();
        const dateB = new Date(b.date || 0).getTime();

        return dateB - dateA;

    });


    if (activities.length > 0) {

        activityTable.innerHTML = "";

        activities.slice(0, 8).forEach(item => {

            const row = document.createElement("tr");

            const typeCell = document.createElement("td");
            const documentCell = document.createElement("td");
            const resultCell = document.createElement("td");
            const dateCell = document.createElement("td");

            typeCell.textContent = item.type;
            documentCell.textContent = item.document;

            if (item.result !== null) {

                const badge = document.createElement("span");

                badge.className = "result-badge";

                badge.textContent =
                    Math.round(item.result) + "%";

                resultCell.appendChild(badge);

            } else {

                resultCell.textContent = "Completed";

            }

            if (item.date) {

                const date = new Date(item.date);

                dateCell.textContent =
                    Number.isNaN(date.getTime())
                        ? String(item.date)
                        : date.toLocaleDateString("en-IN");

            } else {

                dateCell.textContent = "Date unavailable";

            }

            row.appendChild(typeCell);
            row.appendChild(documentCell);
            row.appendChild(resultCell);
            row.appendChild(dateCell);

            activityTable.appendChild(row);

        });

    }


    // =========================================
    // LOGOUT
    // =========================================

    document.getElementById("logoutBtn")
        .addEventListener("click", function () {

            sessionStorage.removeItem("loggedInUser");

            window.location.href = "login.html";

        });

});
