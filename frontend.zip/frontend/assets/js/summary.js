// ==========================================
// GET STORED DATA
// ==========================================

const uploadedFile = JSON.parse(localStorage.getItem("uploadedFile"));

const summaryData = JSON.parse(localStorage.getItem("summary"));

if (!uploadedFile || !summaryData) {

    alert("No summary available.");

    window.location.href = "upload.html";

}



// ==========================================
// FILE INFORMATION
// ==========================================

document.getElementById("fileName").innerText =
uploadedFile.filename;

document.getElementById("fileStats").innerText =
uploadedFile.size;



// ==========================================
// SUMMARY
// ==========================================

document.getElementById("summaryContent").innerText =
summaryData.summary;



// ==========================================
// STATISTICS
// ==========================================

document.getElementById("wordCount").innerText =
summaryData.word_count;

document.getElementById("characterCount").innerText =
summaryData.character_count;

const readingTime =
Math.max(1, Math.ceil(summaryData.word_count / 200));

document.getElementById("readingTime").innerText =
readingTime + " Min";



// ==========================================
// DOWNLOAD SUMMARY
// ==========================================

document.getElementById("downloadBtn").addEventListener("click", () => {

    const text =

`EduMind AI Summary

==============================

File:
${uploadedFile.filename}

==============================

${summaryData.summary}

==============================

Word Count : ${summaryData.word_count}

Character Count : ${summaryData.character_count}

Estimated Reading Time : ${readingTime} Minute(s)
`;

    const blob = new Blob([text], {

        type: "text/plain"

    });

    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");

    a.href = url;

    a.download = "Summary.txt";

    document.body.appendChild(a);

    a.click();

    document.body.removeChild(a);

    URL.revokeObjectURL(url);

});



// ==========================================
// GENERATE FLASHCARDS
// ==========================================

document.getElementById("flashcardBtn")
.addEventListener("click", (event) => {
    event.preventDefault();
    generateFlashcards();
});

async function generateFlashcards() {

    try {

        const response = await fetch(
            "http://127.0.0.1:5000/flashcards",
            {

                method: "POST",

                headers: {

                    "Content-Type": "application/json"

                },

                body: JSON.stringify({

                    text_file: uploadedFile.text_file

                })

            }
        );

        const data = await response.json();

        if (!response.ok) {

            alert(data.error || "Failed to generate flashcards.");

            return;

        }

        localStorage.setItem(

            "flashcards",

            JSON.stringify(data)

        );

        window.location.href = "flashcards.html";

    }

    catch (error) {

        console.error(error);

        alert("Cannot connect to backend.");

    }

}



// ==========================================
// GENERATE QUIZ
// ==========================================

document.getElementById("quizBtn")
.addEventListener("click", (event) => {
    event.preventDefault();
    generateQuiz();
});

async function generateQuiz() {

    try {

        // Never open a previously generated quiz while the backend creates
        // the current document's quality-checked quiz.
        localStorage.removeItem("quiz");

        const response = await fetch(
            "http://127.0.0.1:5000/quiz",
            {

                method: "POST",

                headers: {

                    "Content-Type": "application/json"

                },

                body: JSON.stringify({

                    text_file: uploadedFile.text_file

                })

            }
        );

        const data = await response.json();

        if (!response.ok) {

            alert(data.error || "Failed to generate quiz.");

            return;

        }

        localStorage.setItem(

            "quiz",

            JSON.stringify(data)

        );

        window.location.href = "quiz.html";

    }

    catch (error) {

        console.error(error);

        alert("Cannot connect to backend.");

    }

}



// ==========================================
// AI CHAT
// ==========================================

// ==========================================
// SAVE HISTORY
// ==========================================

let history =

JSON.parse(localStorage.getItem("history")) || [];

history.push({

    filename: uploadedFile.filename,

    date: new Date().toLocaleString(),

    words: summaryData.word_count

});

localStorage.setItem(

    "history",

    JSON.stringify(history)

);