const signupForm = document.getElementById("signupForm");

if(signupForm){

signupForm.addEventListener("submit",function(e){

e.preventDefault();

const name=document.getElementById("name").value.trim();

const email=document.getElementById("email").value.trim();

const password=document.getElementById("password").value;

const confirmPassword=document.getElementById("confirmPassword").value;

if(password!==confirmPassword){

alert("Passwords do not match!");

return;

}

let users=JSON.parse(localStorage.getItem("users")) || [];

const alreadyExists=users.find(user=>user.email===email);

if(alreadyExists){

alert("Email already registered!");

return;

}

const user={

name:name,

email:email,

password:password

};

users.push(user);

localStorage.setItem("users",JSON.stringify(users));

alert("Account created successfully!");

window.location.href="login.html";

});

}




const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", function (e) {

        e.preventDefault();

        const email = document.getElementById("loginEmail").value.trim();
        const password = document.getElementById("loginPassword").value;

        const users = JSON.parse(localStorage.getItem("users")) || [];

        const user = users.find(
            u => u.email === email && u.password === password
        );

        if (!user) {

            alert("Invalid Email or Password");
            return;

        }

        sessionStorage.setItem("loggedInUser", JSON.stringify(user));

        alert("Login Successful!");

        window.location.href = "dashboard.html";

    });

}





function logout(){

sessionStorage.removeItem("loggedInUser");

window.location.href="login.html";

}