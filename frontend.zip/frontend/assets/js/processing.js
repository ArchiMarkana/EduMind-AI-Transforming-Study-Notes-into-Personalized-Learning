// =====================================
// GET FILE INFO
// =====================================

const uploadedFile = JSON.parse(localStorage.getItem("uploadedFile"));

if (!uploadedFile) {

    alert("No uploaded file found.");

    window.location.href = "upload.html";

}

document.getElementById("fileName").innerText =
uploadedFile.filename || "Unknown File";

document.getElementById("fileSize").innerText =
uploadedFile.size || "-";



// =====================================
// PROCESS STEPS
// =====================================

const progressBar = document.getElementById("progress");

const progressText = document.getElementById("progressText");

const steps = [

    document.getElementById("step1"),

    document.getElementById("step2"),

    document.getElementById("step3"),

    document.getElementById("step4"),

    document.getElementById("step5")

];

let current = 0;

const percentages = [20,40,60,80,100];



function nextStep(){

    if(current>0){

        steps[current-1].classList.remove("active");

        steps[current-1].classList.add("completed");

    }

    if(current<steps.length){

        steps[current].classList.add("active");

        progressBar.style.width=percentages[current]+"%";

        progressText.innerText=percentages[current]+"%";

        current++;

    }

}



// =====================================
// START ANIMATION
// =====================================

const animation = setInterval(()=>{

    nextStep();

    if(current===steps.length){

        clearInterval(animation);

        setTimeout(processDocument,1000);

    }

},1200);



// =====================================
// CALL BACKEND
// =====================================

async function processDocument(){

    try{

        const response = await fetch("http://127.0.0.1:5000/process",{

            method:"POST",

            headers:{

                "Content-Type":"application/json"

            },

            // body:JSON.stringify({

            //     filename:uploadedFile.filename

            // })
            
            body: JSON.stringify({

            text_file: uploadedFile.text_file

            })

        });

        const data = await response.json();

        if(response.ok){

            localStorage.setItem(

                "summary",

                JSON.stringify(data)

            );

            window.location.href="summary.html";

        }

        else{

            alert(data.error);

            window.location.href="upload.html";

        }

    }

    catch(error){

        console.error(error);

        alert("Backend processing failed.");

        window.location.href="upload.html";

    }

}