// ==============================
// CHECK LOGIN
// ==============================

const loggedInUser = JSON.parse(sessionStorage.getItem("loggedInUser"));

if (!loggedInUser) {

    alert("Please login first.");

    window.location.href = "login.html";

}

// ==============================
// DISPLAY USER NAME
// ==============================

const username = document.getElementById("username");

if (username && loggedInUser) {

    username.innerText = loggedInUser.name;

}

// ==============================
// LOGOUT
// ==============================

function logout() {

    sessionStorage.removeItem("loggedInUser");

    alert("Logged out successfully!");

    window.location.href = "login.html";

}

// ==============================
// DOCUMENT STORAGE
// ==============================

// If upload list doesn't exist

if (!localStorage.getItem("documents")) {

    localStorage.setItem("documents", JSON.stringify([]));

}

const documents = JSON.parse(localStorage.getItem("documents"));

// ==============================
// DOCUMENT COUNT
// ==============================

const docCount = document.getElementById("docCount");

if (docCount) {

    docCount.innerText = documents.length;

}

// ==============================
// RECENT ACTIVITY
// ==============================

const activityTable = document.getElementById("activityTable");

if (activityTable) {

    const realActivities = [];

    documents.forEach(doc => {
        realActivities.push({
            document: doc.name || doc.filename || "Study Document",
            status: "Uploaded",
            date: doc.date || "Date unavailable"
        });
    });

    flashcardHistory.forEach(item => {
        realActivities.push({
            document: item.filename || "Study Document",
            status: "Flashcards studied",
            date: item.studiedOn || item.date || "Date unavailable"
        });
    });

    quizHistory.forEach(item => {
        realActivities.push({
            document: item.filename || "Study Document",
            status: item.percentage !== undefined
                ? `Quiz completed - ${item.percentage}%`
                : "Quiz completed",
            date: item.completedAt || item.completedOn || item.date || "Date unavailable"
        });
    });

    activityTable.innerHTML = "";

    if (realActivities.length === 0) {
        activityTable.innerHTML = `
            <tr>
                <td colspan="3" style="text-align:center;">
                    No learning activity yet.
                </td>
            </tr>
        `;
    } else {
        realActivities
            .sort((a, b) =>
                new Date(b.date || 0).getTime() -
                new Date(a.date || 0).getTime()
            )
            .slice(0, 8)
            .forEach(item => {
                activityTable.innerHTML += `
                    <tr>
                        <td>${item.document}</td>
                        <td>
                            <span style="color:green;font-weight:600;">
                                ${item.status}
                            </span>
                        </td>
                        <td>${item.date}</td>
                    </tr>
                `;
            });
    }

}

// ==============================
// REAL ACTIVITY STATISTICS
// ==============================

function getArray(key) {
    try {
        const value = JSON.parse(localStorage.getItem(key));
        return Array.isArray(value) ? value : [];
    } catch (error) {
        return [];
    }
}

function getObject(key) {
    try {
        return JSON.parse(localStorage.getItem(key));
    } catch (error) {
        return null;
    }
}

const uploadedFile = getObject("uploadedFile");
const summaryData = getObject("summary");
const flashcardData = getObject("flashcards");
const quizHistory = getArray("quizHistory");
const flashcardHistory = getArray("flashcardHistory");

const summaryCount =
    summaryData &&
    uploadedFile &&
    summaryData.text_file === uploadedFile.text_file
        ? 1
        : 0;

const flashcards = flashcardData &&
    Array.isArray(flashcardData.flashcards)
        ? flashcardData.flashcards
        : [];

const flashcardCount =
    flashcardHistory.length > 0
        ? flashcardHistory.reduce((total, item) =>
            total + Number(item.totalCards || item.cardsStudied || 0),
            0
        )
        : (flashcards.length || 0);

const summaryCountElement =
    document.getElementById("summaryCount");
const flashcardCountElement =
    document.getElementById("flashcardCount");
const quizCountElement =
    document.getElementById("quizCount");

if (summaryCountElement) {
    summaryCountElement.innerText = summaryCount;
}

if (flashcardCountElement) {
    flashcardCountElement.innerText = flashcardCount;
}

if (quizCountElement) {
    quizCountElement.innerText = quizHistory.length;
}

// ==============================
// GREETING
// ==============================

const hour = new Date().getHours();

let greeting = "Welcome";

if (hour < 12) {

    greeting = "Good Morning";

}
else if (hour < 17) {

    greeting = "Good Afternoon";

}
else {

    greeting = "Good Evening";

}

const heading = document.querySelector(".topbar h1");

if (heading) {

    heading.innerHTML = `${greeting}, <span id="username">${loggedInUser.name}</span> 👋`;

}