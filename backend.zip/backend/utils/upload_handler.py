import os
from werkzeug.utils import secure_filename

# Allowed file extensions
ALLOWED_EXTENSIONS = {
    "pdf",
    "doc",
    "docx",
    "ppt",
    "pptx"
}

MAX_FILE_SIZE = 50 * 1024 * 1024   # 50 MB


def allowed_file(filename):

    return "." in filename and \
           filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def format_size(size):

    if size < 1024:
        return f"{size} Bytes"

    elif size < 1024 * 1024:
        return f"{size/1024:.2f} KB"

    elif size < 1024 * 1024 * 1024:
        return f"{size/(1024*1024):.2f} MB"

    else:
        return f"{size/(1024*1024*1024):.2f} GB"


def save_uploaded_file(file, upload_folder):

    if not allowed_file(file.filename):

        return {
            "success": False,
            "error": "Unsupported file format."
        }

    filename = secure_filename(file.filename)

    save_path = os.path.join(upload_folder, filename)

    file.save(save_path)

    file_size = os.path.getsize(save_path)

    if file_size > MAX_FILE_SIZE:

        os.remove(save_path)

        return {
            "success": False,
            "error": "File exceeds 50 MB."
        }

    return {

        "success": True,

        "filename": filename,

        "filepath": save_path,

        "size": format_size(file_size),

        "message": "File uploaded successfully."

    }