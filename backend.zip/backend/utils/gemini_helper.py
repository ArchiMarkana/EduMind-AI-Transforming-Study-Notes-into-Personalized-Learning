import os
import json
import re

from dotenv import load_dotenv
from google import genai


# ============================================================
# LOAD ENVIRONMENT VARIABLES
# ============================================================

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")

if not API_KEY:
    raise ValueError(
        "GEMINI_API_KEY not found in .env file"
    )


# ============================================================
# GEMINI CLIENT
# ============================================================

client = genai.Client(
    api_key=API_KEY
)

MODEL_NAME = "gemini-3.1-flash-lite"


# ============================================================
# CLEAN GEMINI RESPONSE
# ============================================================

def clean_response(text):
    """
    Removes markdown code fences if Gemini returns
    JSON inside ```json ... ``` blocks.
    """

    if not text:
        return ""

    text = text.strip()

    text = re.sub(
        r"^```json\s*",
        "",
        text,
        flags=re.IGNORECASE
    )

    text = re.sub(
        r"^```\s*",
        "",
        text
    )

    text = re.sub(
        r"\s*```$",
        "",
        text
    )

    return text.strip()


def clean_summary_text(text):
    if not text:
        return ""

    text = clean_response(text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)
    text = re.sub(r"(?m)^\s*[-*]\s+", "", text)
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()


def generate_local_quiz(document_text, max_questions=10):
    """Create parallel, document-grounded questions when Gemini fails."""

    text = " ".join(document_text.lower().split())
    questions = []

    def add(question, options, answer, required_terms):
        if all(term in text for term in required_terms):
            questions.append({
                "question": question,
                "options": options,
                "answer": answer
            })

    add(
        "Which property allows a metal to be beaten into thin sheets?",
        ["Ductility", "Malleability", "Sonority", "Conductivity"],
        "Malleability",
        ["malleable", "ductile", "sonorous"]
    )
    add(
        "Which property allows a metal to be drawn into wires?",
        ["Malleability", "Ductility", "Lustre", "Brittleness"],
        "Ductility",
        ["ductile", "malleable", "brittle"]
    )
    add(
        "Which material is identified as an exception to the poor conductivity of non-metals?",
        ["Sulfur", "Carbon in the form of graphite", "Phosphorus", "Nitrogen"],
        "Carbon in the form of graphite",
        ["poor conductors", "graphite", "non-metals"]
    )
    add(
        "What gas is produced when metals react with dilute acids?",
        ["Oxygen", "Nitrogen", "Hydrogen", "Carbon dioxide"],
        "Hydrogen",
        ["dilute acids", "hydrogen gas"]
    )
    add(
        "What type of ions do non-metals tend to form?",
        ["Positive ions", "Negative ions", "Metal ions", "Neutral atoms only"],
        "Negative ions",
        ["gain electrons", "negative ions"]
    )
    add(
        "Which metal is listed for use in electrical wiring?",
        ["Iron", "Copper", "Aluminium", "Gold"],
        "Copper",
        ["copper", "electrical wiring"]
    )
    add(
        "What does corrosion describe?",
        [
            "The gradual destruction of metals by chemical reactions",
            "The drawing of metals into wires",
            "The production of sound by metals",
            "The classification of materials by colour"
        ],
        "The gradual destruction of metals by chemical reactions",
        ["corrosion", "gradual destruction"]
    )
    add(
        "Which method is listed for preventing corrosion?",
        ["Painting", "Melting", "Pulverising", "Diluting"],
        "Painting",
        ["prevention methods", "painting"]
    )
    add(
        "Which metal is highest in the reactivity series given in the document?",
        ["Gold", "Copper", "Potassium", "Silver"],
        "Potassium",
        ["reactivity series", "potassium", "gold"]
    )
    add(
        "Which use of aluminium is given in the document?",
        ["Electrical wiring", "Aircraft, utensils, and foil", "Water purification", "Respiration"],
        "Aircraft, utensils, and foil",
        ["aluminium", "aircraft", "utensils"]
    )

    return questions[:max_questions]


# ============================================================
# GENERATE SUMMARY
# ============================================================

def generate_summary(document_text):
    """
    Generate an AI-powered summary from the uploaded document.
    """

    try:

        prompt = f"""
You are EduMind AI, an educational study assistant.

Read the uploaded study material carefully and create a
useful summary for a student.

IMPORTANT:
Use ONLY information contained in the document.

Do NOT add outside information.
Do NOT invent facts.

SUMMARY REQUIREMENTS:

- Write approximately 150-250 words.
- For long documents, cover all major sections in 300-500 words.
- Return plain prose with complete sentences.
- Do not use Markdown, headings, bold text, bullet points, or lists.
- Use one or two readable paragraphs.
- Use simple and clear English.
- Include the important concepts from the document.
- Remove unnecessary repetition.
- Preserve important definitions, classifications,
  properties, examples, and explanations.
- Organize the information logically.
- Make the summary useful for exam revision.
- Do not mention that you are an AI.
- Do not say "according to the document".

Return ONLY the summary text.

DOCUMENT:

{document_text}
"""

        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=prompt
        )

        if not response.text:
            return "Unable to generate summary."

        return clean_summary_text(response.text)

    except Exception as e:

        print("Summary Error:", e)

        return "Unable to generate summary."


# ============================================================
# GENERATE FLASHCARDS
# ============================================================

def generate_flashcards(document_text):
    """
    Generate exactly 10 high-quality flashcards
    based only on the uploaded document.
    """

    try:

        prompt = f"""
You are EduMind AI, an educational flashcard generator.

Read the uploaded study material carefully.

Create exactly 10 useful flashcards for studying.

IMPORTANT:
Use ONLY information explicitly present in the document.

Do NOT use outside knowledge.
Do NOT invent facts.

============================================================
FLASHCARD QUESTION RULES
============================================================

Every question must:

- Be complete.
- Be grammatically correct.
- Be specific.
- Clearly identify the topic being asked about.
- Test an important concept from the document.
- Be understandable without seeing the document.

NEVER create vague questions such as:

"What is?"
"What are?"
"What is Science?"
"What is Examples?"
"What is Physical?"
"Which is?"

BAD:

"What is Examples?"

GOOD:

"What are examples of metals mentioned in the document?"

BAD:

"What is Physical?"

GOOD:

"What are the physical properties of metals described
in the document?"

BAD:

"What is?"

GOOD:

"What happens when metals react with oxygen?"

============================================================
ANSWER RULES
============================================================

- The answer must be directly supported by the document.
- Do not invent information.
- Keep answers concise but complete.
- Do not use information from outside the document.
- Do not answer with vague phrases.

============================================================
QUALITY CHECK
============================================================

Before returning the flashcards, check every question:

1. Is it complete?
2. Is it specific?
3. Does it clearly identify the topic?
4. Is it based on the document?
5. Can the answer be found in the document?
6. Is the answer useful for studying?

If a question fails any check, rewrite it.

============================================================
OUTPUT FORMAT
============================================================

Return ONLY valid JSON.

Do NOT use markdown.

Do NOT use ```json.

Do NOT include explanations.

Return exactly:

[
    {{
        "question": "Complete question?",
        "answer": "Answer based on the document."
    }}
]

============================================================
DOCUMENT
============================================================

{document_text}
"""

        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=prompt
        )

        text = clean_response(response.text)

        flashcards = json.loads(text)

        # ====================================================
        # VALIDATE FLASHCARDS
        # ====================================================

        valid_flashcards = []

        for item in flashcards:

            if not isinstance(item, dict):
                continue

            question = item.get("question")
            answer = item.get("answer")

            if not isinstance(question, str):
                continue

            if not isinstance(answer, str):
                continue

            question = question.strip()
            answer = answer.strip()

            # Question must have reasonable length
            if len(question) < 15:
                continue

            # Answer must not be empty
            if len(answer) < 2:
                continue

            # Reject vague questions
            bad_questions = [
                "what is?",
                "what are?",
                "which is?",
                "which are?",
                "what is the?",
                "what is science?",
                "what is examples?",
                "what is physical?"
            ]

            if question.lower() in bad_questions:
                continue

            valid_flashcards.append({
                "question": question,
                "answer": answer
            })

        print(
            "Generated valid flashcards:",
            len(valid_flashcards)
        )

        return valid_flashcards[:10]

    except Exception as e:

        print("Flashcard Error:", e)

        return []


# ============================================================
# GENERATE QUIZ
# ============================================================

def generate_quiz(document_text):
    """
    Generate 10 high-quality MCQs using only information
    available in the uploaded document.
    """

    try:

        prompt = f"""
You are EduMind AI, an educational quiz generator.

Your task is to create a high-quality multiple-choice
quiz from the uploaded study material.

IMPORTANT:

Use ONLY information explicitly present in the document.

Do NOT use outside knowledge.

Do NOT invent facts.

============================================================
STEP 1 - FIND IMPORTANT INFORMATION
============================================================

First, silently identify important information from the
document, including:

- Definitions
- Properties
- Examples
- Classifications
- Characteristics
- Differences
- Uses
- Processes
- Important facts
- Important relationships

Do NOT use headings alone as questions.

Do NOT create questions from isolated or incomplete words.

============================================================
STEP 2 - CREATE QUESTIONS
============================================================

Create exactly 10 multiple-choice questions.

Every question MUST:

- Be complete.
- Be grammatically correct.
- Clearly identify what is being asked.
- Test one specific concept.
- Be answerable from the document.
- Make sense by itself.
- Be useful for a student preparing for an exam.

NEVER create vague questions.

BAD:

"What is?"

"What is Science?"

"What is Examples?"

"What is Physical?"

"What is Chemical?"

"Which is?"

"Which are?"

GOOD:

"Which of the following is a physical property of metals?"

GOOD:

"Which metals are listed as examples in the document?"

GOOD:

"What happens when metals react with oxygen?"

============================================================
STEP 3 - CREATE OPTIONS
============================================================

Every question MUST contain exactly 4 options.

There must be:

- 1 correct answer
- 3 incorrect answers

VERY IMPORTANT:

The three incorrect answers MUST be plausible alternatives
for the exact question, not merely true statements from
somewhere else in the document. Derive them from the same
concept, category, process, or comparison as the correct
answer.

Do NOT create random unrelated options.

Every option must answer the question's grammatical stem.
If the question asks for one item, use four comparable items.
If it asks for a definition, use four definitions of the same
kind of term. If it asks about a process or result, use four
results that could reasonably be confused.

The correct answer must not be identifiable because it is
longer, more detailed, more technical, or the only complete
sentence. Keep options parallel in grammar, specificity, and
length. Do not copy entire unrelated sentences from the
document.

It is acceptable for distractors to be plausible inferences
from the document, but they must be false for the exact
question. Never use a true statement about a different topic
as a distractor.

============================================================
FORBIDDEN OPTIONS
============================================================

NEVER use:

"None of the above"

"All of the above"

"None"

"Not mentioned"

"Not present in the document"

"Cannot be determined"

"Not available"

"Not specified"

"Science is not mentioned in the document"

"Examples is not mentioned in the document"

"Physical is not mentioned in the document"

or any similar placeholder.

============================================================
OPTION QUALITY
============================================================

All four options must be reasonably similar in type,
length, and topic.

Do NOT make the correct answer obvious because it is
much longer than the other options.

Do NOT use an entire paragraph as an option.

BAD:

Option A:
A very long paragraph containing the complete explanation
of the topic and several facts.

GOOD:

Option A:
Malleability

Option B:
Ductility

Option C:
Sonority

Option D:
Brittleness

============================================================
ONE CORRECT ANSWER
============================================================

Only ONE option can be correct.

The other three must be incorrect for the specific
question but still plausible and related.

The "answer" field MUST exactly match one of the options.

============================================================
FINAL QUALITY CHECK
============================================================

Before returning the quiz, silently check EVERY question.

For each question verify:

1. Is the question complete?
2. Is the topic clearly identified?
3. Is the question based on the document?
4. Can the answer be found in the document?
5. Does every option answer the same question stem?
6. Are the options similar in type, grammar, specificity, and length?
7. Are the distractors false for this question rather than merely unrelated?
8. Is exactly one option correct?
9. Does the answer exactly match an option?
10. Is there any forbidden option?
11. Is the correct answer obviously longer or more detailed?
12. Is the question vague or based only on a heading?

If ANY question fails these checks,
rewrite that question before returning the result.

============================================================
OUTPUT FORMAT
============================================================

Return ONLY valid JSON.

Do NOT return markdown.

Do NOT return ```json.

Do NOT include explanations.

Return exactly:

[
    {{
        "question": "Complete question?",
        "options": [
            "Option A",
            "Option B",
            "Option C",
            "Option D"
        ],
        "answer": "Option A"
    }}
]

============================================================
UPLOADED DOCUMENT
============================================================

{document_text}
"""

        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=prompt
        )

        text = clean_response(response.text)

        quiz = json.loads(text)

        # ====================================================
        # VALIDATE QUIZ
        # ====================================================

        valid_quiz = []

        invalid_option_phrases = [
            "none of the above",
            "all of the above",
            "not mentioned",
            "not present in the document",
            "cannot be determined",
            "not available",
            "not specified"
        ]

        bad_questions = [
            "what is?",
            "what are?",
            "which is?",
            "which are?",
            "what is the?",
            "what is science?",
            "what is examples?",
            "what is physical?",
            "what is chemical?"
        ]

        for item in quiz:

            if not isinstance(item, dict):
                continue

            question = item.get("question")
            options = item.get("options")
            answer = item.get("answer")

            # ------------------------------------------------
            # Question validation
            # ------------------------------------------------

            if not isinstance(question, str):
                continue

            question = question.strip()

            if len(question) < 15:
                continue

            if question.lower() in bad_questions:
                continue

            if question.lower().startswith(
                "which statement correctly describes"
            ):
                continue

            # Reject questions ending in an incomplete pattern
            incomplete_patterns = [
                "what is?",
                "what are?",
                "which is?",
                "which are?"
            ]

            if any(
                question.lower().endswith(pattern)
                for pattern in incomplete_patterns
            ):
                continue

            # ------------------------------------------------
            # Options validation
            # ------------------------------------------------

            if not isinstance(options, list):
                continue

            if len(options) != 4:
                continue

            if not all(
                isinstance(option, str)
                for option in options
            ):
                continue

            options = [
                option.strip()
                for option in options
            ]

            # No empty options
            if any(not option for option in options):
                continue

            # ------------------------------------------------
            # Duplicate options
            # ------------------------------------------------

            normalized_options = [
                option.lower()
                for option in options
            ]

            if len(set(normalized_options)) != 4:
                continue

            # ------------------------------------------------
            # Forbidden options
            # ------------------------------------------------

            has_invalid_option = False

            for option in normalized_options:

                for phrase in invalid_option_phrases:

                    if phrase in option:
                        has_invalid_option = True
                        break

                if has_invalid_option:
                    break

            if has_invalid_option:
                continue

            # ------------------------------------------------
            # Reject extremely long options
            # ------------------------------------------------

            if any(
                len(option) > 250
                for option in options
            ):
                continue

            # ------------------------------------------------
            # Answer validation
            # ------------------------------------------------

            if not isinstance(answer, str):
                continue

            answer = answer.strip()

            if answer not in options:
                continue

            # ------------------------------------------------
            # Add valid question
            # ------------------------------------------------

            valid_quiz.append({

                "question": question,

                "options": options,

                "answer": answer

            })

        if valid_quiz:
            print(
                "Generated valid quiz questions:",
                len(valid_quiz)
            )
            return valid_quiz[:10]

        fallback_quiz = generate_local_quiz(document_text)
        print(
            "Gemini returned no usable questions; generated "
            "document-grounded fallback questions:",
            len(fallback_quiz)
        )
        return fallback_quiz

    except Exception as e:

        print("Quiz Error:", e)

        fallback_quiz = generate_local_quiz(document_text)
        print(
            "Gemini quiz generation failed; no low-quality fallback quiz "
            "was returned."
        )
        return fallback_quiz


# ============================================================
# ASK QUESTION
# ============================================================

def ask_question(document_text, question):
    """
    Answers a student's question using only the
    uploaded document.
    """

    try:

        prompt = f"""
You are EduMind AI, a document-based educational
study assistant.

Answer the student's question using ONLY information
contained in the uploaded document.

Do NOT use outside knowledge.

============================================================
RULES
============================================================

- If the answer is clearly available in the document,
  explain it in simple English.
- Keep the answer concise and useful for studying.
- Use approximately 50-150 words.
- Do not invent information.
- Do not assume information that is not present.
- If the document does not contain enough information
  to answer the question, say exactly:

"I couldn't find this information in the uploaded document."

============================================================
DOCUMENT
============================================================

{document_text}

============================================================
STUDENT QUESTION
============================================================

{question}
"""

        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=prompt
        )

        if not response.text:
            return "Unable to answer the question."

        return response.text.strip()

    except Exception as e:

        print("Chat Error:", e)

        return "Unable to answer the question."


# ============================================================
# TEST GEMINI HELPER
# ============================================================

if __name__ == "__main__":

    sample_text = """
    Metals and non-metals have different physical and
    chemical properties.

    Metals are generally lustrous, malleable, ductile
    and good conductors of heat and electricity.

    Examples of metals include iron, copper, aluminium,
    silver and gold.

    Non-metals are generally poor conductors of heat
    and electricity. They are often brittle when solid.

    Examples of non-metals include oxygen, nitrogen,
    sulfur, carbon and phosphorus.

    Metals react with oxygen to form metal oxides.
    """

    # --------------------------------------------------------
    # SUMMARY TEST
    # --------------------------------------------------------

    print("\n")
    print("=" * 60)
    print("AI SUMMARY")
    print("=" * 60)

    summary = generate_summary(sample_text)

    print(summary)


    # --------------------------------------------------------
    # FLASHCARD TEST
    # --------------------------------------------------------

    print("\n")
    print("=" * 60)
    print("AI FLASHCARDS")
    print("=" * 60)

    flashcards = generate_flashcards(sample_text)

    print(
        json.dumps(
            flashcards,
            indent=4,
            ensure_ascii=False
        )
    )


    # --------------------------------------------------------
    # QUIZ TEST
    # --------------------------------------------------------

    print("\n")
    print("=" * 60)
    print("AI QUIZ")
    print("=" * 60)

    quiz = generate_quiz(sample_text)

    print(
        json.dumps(
            quiz,
            indent=4,
            ensure_ascii=False
        )
    )


    # --------------------------------------------------------
    # AI QUESTION TEST
    # --------------------------------------------------------

    print("\n")
    print("=" * 60)
    print("AI QUESTION")
    print("=" * 60)

    answer = ask_question(
        sample_text,
        "What are the physical properties of metals?"
    )

    print(answer)