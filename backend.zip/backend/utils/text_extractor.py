from PyPDF2 import PdfReader
from docx import Document
from pptx import Presentation
import os
import re


def extract_pdf(path):
    reader = PdfReader(path)
    text_parts = []

    for page_number, page in enumerate(reader.pages, start=1):
        extracted = ""

        try:
            extracted = page.extract_text(extraction_mode="layout")
        except (TypeError, AttributeError):
            try:
                extracted = page.extract_text()
            except Exception:
                extracted = ""

        if not extracted:
            continue

        extracted = extracted.replace("\ufffd", "")
        extracted = re.sub(r"[ \t]+", " ", extracted)
        extracted = re.sub(r"\n{3,}", "\n\n", extracted)
        text_parts.append(f"[Page {page_number}]\n{extracted.strip()}")

    return "\n\n".join(text_parts).strip()


def extract_docx(path):

    text = ""

    document = Document(path)

    for para in document.paragraphs:

        text += para.text + "\n"

    return text


def extract_pptx(path):

    text = ""

    presentation = Presentation(path)

    for slide in presentation.slides:

        for shape in slide.shapes:

            if hasattr(shape, "text"):

                text += shape.text + "\n"

    return text


def extract_text(filepath):

    extension = os.path.splitext(filepath)[1].lower()

    if extension == ".pdf":

        return extract_pdf(filepath)

    elif extension == ".docx":

        return extract_docx(filepath)

    elif extension == ".pptx":

        return extract_pptx(filepath)

    elif extension == ".doc":

        return "DOC files are currently not supported. Please upload DOCX."

    elif extension == ".ppt":

        return "PPT files are currently not supported. Please upload PPTX."

    else:

        return "Unsupported File."