from utils.gemini_helper import generate_summary

sample_text = """
Machine learning is a branch of Artificial Intelligence.
It enables computers to learn patterns from data without
being explicitly programmed. Machine learning is widely
used in healthcare, finance, education, robotics, and
recommendation systems.
"""

summary = generate_summary(sample_text)

print("\n===== SUMMARY =====\n")
print(summary)