from flask import Flask, request, jsonify
from flask_cors import CORS

import os
import json

from utils.upload_handler import save_uploaded_file
from utils.text_extractor import extract_text

from utils.gemini_helper import (
    generate_summary,
    generate_flashcards,
    generate_quiz,
    ask_question
)

app = Flask(__name__)

CORS(app)
SUMMARY_CACHE_VERSION = "3"

# ====================================================
# FOLDERS
# ====================================================

UPLOAD_FOLDER = "uploads"
TEXT_FOLDER = "extracted_text"
CACHE_FOLDER = "ai_cache"
QUIZ_CACHE_VERSION = "4"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(TEXT_FOLDER, exist_ok=True)
os.makedirs(CACHE_FOLDER, exist_ok=True)

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["TEXT_FOLDER"] = TEXT_FOLDER
app.config["CACHE_FOLDER"] = CACHE_FOLDER


# ====================================================
# HELPER FUNCTIONS
# ====================================================

def load_extracted_text(text_file):

    text_path = os.path.join(
        app.config["TEXT_FOLDER"],
        text_file
    )

    if not os.path.exists(text_path):
        return None

    with open(text_path, "r", encoding="utf-8") as f:
        return f.read()


def get_cache_folder(text_file):

    folder_name = os.path.splitext(text_file)[0]

    cache_path = os.path.join(
        app.config["CACHE_FOLDER"],
        folder_name
    )

    os.makedirs(cache_path, exist_ok=True)

    return cache_path


def save_text(filepath, text):

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(text)


def load_text(filepath):

    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


def save_json(filepath, data):

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)


def load_json(filepath):

    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)


# ====================================================
# HOME
# ====================================================

@app.route("/")
def home():

    return jsonify({
        "message": "EduMind AI Backend Running"
    })


# ====================================================
# UPLOAD DOCUMENT
# ====================================================

@app.route("/upload", methods=["POST"])
def upload_file():

    if "file" not in request.files:

        return jsonify({
            "success": False,
            "error": "No file selected."
        }), 400

    file = request.files["file"]

    if file.filename == "":

        return jsonify({
            "success": False,
            "error": "No file selected."
        }), 400

    result = save_uploaded_file(
        file,
        app.config["UPLOAD_FOLDER"]
    )

    if not result["success"]:
        return jsonify(result), 400

    filepath = result["filepath"]

    extracted_text = extract_text(filepath)

    filename_without_extension = os.path.splitext(
        result["filename"]
    )[0]

    txt_filename = filename_without_extension + ".txt"

    txt_path = os.path.join(
        app.config["TEXT_FOLDER"],
        txt_filename
    )

    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(extracted_text)

    return jsonify({

        "success": True,

        "filename": result["filename"],

        "size": result["size"],

        "text_file": txt_filename,

        "message": "Upload successful."

    })


# ====================================================
# GENERATE AI SUMMARY
# ====================================================

@app.route("/process", methods=["POST"])
def process_document():

    data = request.get_json()

    if not data:

        return jsonify({
            "success": False,
            "error": "No request data received."
        }), 400

    text_file = data.get("text_file")

    if not text_file:

        return jsonify({
            "success": False,
            "error": "Text file missing."
        }), 400

    extracted_text = load_extracted_text(text_file)

    if extracted_text is None:

        return jsonify({
            "success": False,
            "error": "Extracted text not found."
        }), 404

    cache_folder = get_cache_folder(text_file)

    summary_path = os.path.join(
        cache_folder,
        "summary.txt"
    )
    summary_version_path = os.path.join(
        cache_folder,
        "summary.version"
    )

    # ------------------------------
    # Read cached summary
    # ------------------------------

    summary_is_current = (
        os.path.exists(summary_path)
        and os.path.exists(summary_version_path)
        and load_text(summary_version_path) == SUMMARY_CACHE_VERSION
    )

    if summary_is_current:

        print("Loading cached summary...")

        summary = load_text(summary_path)

        if summary.strip().lower().startswith(
            ("unable to generate summary", "unable to produce")
        ):
            os.remove(summary_path)
            summary = None

        if summary is None:
            print("Regenerating failed summary...")
            summary = generate_summary(extracted_text)

            if not summary.strip().lower().startswith(
                ("unable to generate summary", "unable to produce")
            ):
                save_text(summary_path, summary)
                save_text(summary_version_path, SUMMARY_CACHE_VERSION)

    else:

        print("Generating AI summary...")

        summary = generate_summary(extracted_text)

        save_text(summary_path, summary)
        save_text(summary_version_path, SUMMARY_CACHE_VERSION)

    return jsonify({

        "success": True,

        "summary": summary,

        "word_count": len(extracted_text.split()),

        "character_count": len(extracted_text),

        "text_file": text_file

    })
# ====================================================
# GENERATE AI FLASHCARDS
# ====================================================
# ====================================================
# GENERATE AI FLASHCARDS
# ====================================================

@app.route("/flashcards", methods=["POST"])
def flashcards():

    data = request.get_json()

    if not data:

        return jsonify({
            "success": False,
            "error": "No request data received."
        }), 400

    text_file = data.get("text_file")

    if not text_file:

        return jsonify({
            "success": False,
            "error": "Text file missing."
        }), 400

    extracted_text = load_extracted_text(text_file)

    if extracted_text is None:

        return jsonify({
            "success": False,
            "error": "Extracted text not found."
        }), 404

    cache_folder = get_cache_folder(text_file)

    flashcards_path = os.path.join(
        cache_folder,
        "flashcards.json"
    )

    # ------------------------------
    # Read cached flashcards
    # ------------------------------

    if os.path.exists(flashcards_path):

        print("Loading cached flashcards...")

        flashcards = load_json(flashcards_path)

        if not isinstance(flashcards, list) or not flashcards:
            os.remove(flashcards_path)
            flashcards = None

        if flashcards is None:
            print("Regenerating empty flashcards cache...")
            flashcards = generate_flashcards(extracted_text)
            save_json(flashcards_path, flashcards)

    else:

        print("Generating AI flashcards...")

        flashcards = generate_flashcards(extracted_text)

        save_json(flashcards_path, flashcards)

    return jsonify({

        "success": True,

        "flashcards": flashcards,

        "total_cards": len(flashcards),

        "text_file": text_file

    })


# ====================================================
# GENERATE AI QUIZ
# ====================================================

@app.route("/quiz", methods=["POST"])
def quiz():

    data = request.get_json()

    if not data:

        return jsonify({
            "success": False,
            "error": "No request data received."
        }), 400

    text_file = data.get("text_file")

    if not text_file:

        return jsonify({
            "success": False,
            "error": "Text file missing."
        }), 400

    extracted_text = load_extracted_text(text_file)

    if extracted_text is None:

        return jsonify({
            "success": False,
            "error": "Extracted text not found."
        }), 404

    cache_folder = get_cache_folder(text_file)

    quiz_path = os.path.join(
        cache_folder,
        "quiz.json"
    )
    quiz_version_path = os.path.join(
        cache_folder,
        "quiz.version"
    )

    # ------------------------------
    # Read cached quiz
    # ------------------------------

    if (
        os.path.exists(quiz_path)
        and os.path.exists(quiz_version_path)
        and load_text(quiz_version_path) == QUIZ_CACHE_VERSION
    ):

        print("Loading cached quiz...")

        quiz_data = load_json(quiz_path)

        if not isinstance(quiz_data, list) or not quiz_data:
            os.remove(quiz_path)
            quiz_data = None

    else:

        quiz_data = None

    if quiz_data is None:

        print("Generating AI quiz...")

        quiz_data = generate_quiz(extracted_text)

        if not quiz_data:
            return jsonify({
                "success": False,
                "error": (
                    "Quiz generation failed because the document did not "
                    "contain enough usable text."
                )
            }), 502

        save_json(quiz_path, quiz_data)
        save_text(quiz_version_path, QUIZ_CACHE_VERSION)

    return jsonify({

        "success": True,

        "quiz": quiz_data,

        "total_questions": len(quiz_data),

        "text_file": text_file

    })


# ====================================================
# CLEAR CACHE (OPTIONAL)
# ====================================================

@app.route("/clear-cache/<text_file>", methods=["DELETE"])
def clear_cache(text_file):

    cache_folder = get_cache_folder(text_file)

    if not os.path.exists(cache_folder):

        return jsonify({
            "success": False,
            "message": "Cache not found."
        }), 404

    for file in os.listdir(cache_folder):

        os.remove(os.path.join(cache_folder, file))

    return jsonify({

        "success": True,

        "message": "AI cache cleared successfully."

    })


# ====================================================
# ASK AI ABOUT DOCUMENT
# ====================================================

@app.route("/chat", methods=["POST"])
def chat():

    data = request.get_json()

    if not data:
        return jsonify({
            "success": False,
            "error": "No request data received."
        }), 400

    text_file = data.get("text_file")
    question = data.get("question")

    if not isinstance(text_file, str) or not text_file.strip():
        return jsonify({
            "success": False,
            "error": "Text file missing."
        }), 400

    if not isinstance(question, str) or not question.strip():
        return jsonify({
            "success": False,
            "error": "Question cannot be empty."
        }), 400

    extracted_text = load_extracted_text(text_file)

    if extracted_text is None:
        return jsonify({
            "success": False,
            "error": "Extracted text not found."
        }), 404

    answer = ask_question(extracted_text, question.strip())

    return jsonify({
        "success": True,
        "answer": answer,
        "text_file": text_file
    })


# ====================================================
# START SERVER
# ====================================================

if __name__ == "__main__":

    app.run(
        debug=True,
        host="0.0.0.0",
        port=5000
    )