import re


def clean_text(text):
    text = text.replace("\n", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def split_sentences(text):
    sentences = re.split(r'(?<=[.!?])\s+', text)
    return [s.strip() for s in sentences if len(s.strip()) > 25]


def generate_quiz(text, max_questions=10):

    text = clean_text(text)

    sentences = split_sentences(text)

    quiz = []

    used = set()

    for sentence in sentences:

        if len(quiz) >= max_questions:
            break

        if sentence in used:
            continue

        used.add(sentence)

        words = sentence.split()

        if len(words) < 6:
            continue

        keyword = words[0]

        question = f"What is {keyword}?"

        correct_answer = sentence

        options = [
            correct_answer,
            "None of the above",
            "All of the above",
            f"{keyword} is not mentioned in the document"
        ]

        quiz.append({
            "question": question,
            "options": options,
            "answer": correct_answer
        })

    if len(quiz) == 0:

        quiz.append({
            "question": "No Quiz Available",
            "options": [
                "Document too short",
                "Not enough information",
                "Upload another document",
                "Try again"
            ],
            "answer": "Document too short"
        })

    return quiz