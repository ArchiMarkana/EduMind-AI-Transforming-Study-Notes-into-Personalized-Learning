import re


def clean_text(text):
    """
    Clean extracted text.
    """

    text = text.replace("\n", " ")

    text = re.sub(r"\s+", " ", text)

    return text.strip()


def split_sentences(text):
    """
    Split text into sentences.
    """

    sentences = re.split(r'(?<=[.!?])\s+', text)

    return [s.strip() for s in sentences if len(s.strip()) > 20]


def generate_flashcards(text, max_cards=15):
    """
    Generate flashcards from extracted text.
    """

    text = clean_text(text)

    sentences = split_sentences(text)

    flashcards = []

    used = set()

    for sentence in sentences:

        if len(flashcards) >= max_cards:
            break

        sentence = sentence.strip()

        if sentence in used:
            continue

        used.add(sentence)

        words = sentence.split()

        if len(words) < 6:
            continue

        keyword = words[0]

        question = f"What is {keyword}?"

        answer = sentence

        flashcards.append({

            "question": question,

            "answer": answer

        })

    if len(flashcards) == 0:

        flashcards.append({

            "question": "No Flashcards",

            "answer": "Not enough information found in the document."

        })

    return flashcards